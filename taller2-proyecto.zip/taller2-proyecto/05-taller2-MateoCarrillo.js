/* ============================================================================
   TALLER 2 - "LA PRIMERA DECISIÓN DE MI PROYECTO"   Clase 12 · Viernes 25-09-2026
   ----------------------------------------------------------------------------
   Hasta ahora tu programa solo GUARDA y MUESTRA datos. Hoy va a DECIDIR.

   Una condicional es exactamente lo que dice: "si pasa esto, haz aquello;
   si no, haz esto otro". Es la misma frase que usas todos los días:

       si  (está lloviendo)  -> llevo sombrilla
       si no                 -> no la llevo

   En JavaScript:
       if (condicion) {
         // lo que pasa cuando la condición es verdadera
       } else {
         // lo que pasa cuando NO
       }

   OPERADORES DE COMPARACIÓN que vas a necesitar hoy:
       ===   igual a           (SIEMPRE tres iguales, nunca dos)
       !==   distinto de
       >     mayor que         >=  mayor o igual que
       <     menor que         <=  menor o igual que

   ⚠️ El error más caro del semestre:  if (x = 5)  NO compara, ASIGNA.
      Comparar es  if (x === 5).  Un igual = guarda. Tres iguales === preguntan.

   CÓMO EJECUTARLO:  05-taller2-plantilla.js
   ENTREGA: archivo renombrado como  taller2-TUNOMBREYAPELLIDO.js
   ========================================================================== */


/* ----------------------------------------------------------------------------
   PASO 0 - Trae tus variables del Taller 1 (cópialas aquí)
   ---------------------------------------------------------------------------- */

const tipoInmueble = Object.freeze(["Casa", "Apartamento", "Patio", "Salon de Eventos"]); // string
const direccion = "Calle 1 # 2-3";    // string
let tipoPago = "mes";                 // string
let tamaño = 120.00;                  // number
let precioArriendo = 1000000;        // number
let disponible = true;                // boolean..


/* ----------------------------------------------------------------------------
   PASO 1 (8 min) - La decisión de disponibilidad
   Escribe un if/else que revise si tu entidad está disponible e imprima un
   mensaje distinto en cada caso.

   Ejemplos según el proyecto:
     Inventario  -> si las unidades son mayores a 0: "Disponible", si no: "AGOTADO"
     Biblioteca  -> si hay ejemplares libres: "Se puede prestar", si no: "En espera"
     Citas       -> si el cupo del día es menor al máximo: "Agenda abierta", si no: "Día lleno"
   ---------------------------------------------------------------------------- */
   

   if (disponible === true) {
   console.log("El inmueble está disponible para arriendo");
} else {
   console.log("El inmueble no está disponible para arriendo");
}


/* ----------------------------------------------------------------------------
   PASO 2 (10 min) - Tres niveles con else if
   Ahora tu proyecto debe distinguir TRES situaciones, no dos. Usa el esquema:

       if (caso más exigente) { ... }
       else if (caso intermedio) { ... }
       else { ... }

   ⚠️ El orden importa: JavaScript revisa de arriba hacia abajo y se queda con
   la PRIMERA condición que se cumpla. Si pones la más floja de primeras, las
   de abajo nunca se ejecutan.

   Ejemplos:
     Inventario  -> 0 unidades = AGOTADO / menos de 5 = STOCK BAJO / resto = OK
     Notas       -> >= 4.5 Excelente / >= 3.0 Aprobado / resto Reprobado
     Parqueadero -> 0 celdas = LLENO / menos de 10 = CASI LLENO / resto = DISPONIBLE
   ---------------------------------------------------------------------------- */

   if ( tamaño >= 120 ) {
      console.log("El inmueble es grande");  
   } else if ( tamaño >= 60 ) {
      console.log("El inmueble es mediano");  
   } else {
      console.log("El inmueble es pequeño");  
   }


/* ----------------------------------------------------------------------------
   PASO 3 (7 min) - Una decisión con DOS condiciones a la vez
   Operadores lógicos:
       &&   "Y"  -> se deben cumplir LAS DOS
       ||   "O"  -> basta con que se cumpla UNA
       !    "NO" -> invierte

   Escribe una regla real de tu proyecto que necesite dos condiciones.
   Ejemplos:
     "Se aplica descuento SI el cliente es frecuente Y compra más de 3 unidades"
     "Se puede prestar SI hay ejemplares Y el usuario no tiene multas"
     "Alerta SI el stock es bajo O el producto está vencido"
   ---------------------------------------------------------------------------- */
   const casa1 = {
      tipoInmueble: "Apartamento",
      disponible: true,
      precioArriendo: 1000000
   };
   const cliente1 = {
      presupuesto: 1200000
   };
 if ( casa1.disponible === true && casa1.precioArriendo <= cliente1.presupuesto ) {
   console.log("Este apartamento esta en tu presupuesto y está disponible para arriendo");
 }


/* ----------------------------------------------------------------------------
   PASO 4 (5 min) - Escríbelo en español, debajo del código
   En un comentario de 2 o 3 líneas, explica la regla del Paso 3 como se la
   explicarías al DUEÑO del negocio, sin usar una sola palabra técnica.
   Esto es lo que se te va a preguntar en la sustentación final.
   ---------------------------------------------------------------------------- */

// REGLA DE NEGOCIO:
// Esta regla indica que el apartamento solo se puede arrendar si está disponible y si el precio del arriendo es menor o igual al presupuesto del cliente.
// ______________________________________________________________


/* ----------------------------------------------------------------------------
   RETO OPCIONAL (+0.3) - El operador ternario
   La misma decisión de dos caminos, escrita en una sola línea:
       const estado = (unidades > 0) ? "Disponible" : "Agotado";
   Reescribe así tu condicional del Paso 1 y úsala dentro de un template literal.
   ---------------------------------------------------------------------------- */

   const estado = (disponible === true) ? "Disponible" : "No disponible";
   console.log(`El inmueble está ${estado} para arriendo`);