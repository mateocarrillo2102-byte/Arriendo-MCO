/* ============================================================================
   EJERCICIO EN CLASE - "EL CATÁLOGO DE MI PROYECTO"
   Clase 8 · Lunes 05-10-2026 · 30 minutos
   ----------------------------------------------------------------------------
   Hasta hoy tu programa tenía UN registro: un pedido, un producto, una ruta.
   Un sistema de verdad tiene MUCHOS. Hoy tu proyecto deja de tener un
   registro y pasa a tener una tabla.

   CÓMO EJECUTARLO: clic derecho sobre 08-catalogo-de-mi-proyecto.html ->
   "Open with Live Server", y en el navegador F12 -> pestaña Console.

   ENTREGA: este archivo renombrado como  08-catalogo-TUAPELLIDO.js
   Y con los nombres de TODOS los integrantes escritos aquí abajo.

   GRUPO:
   INTEGRANTES:
   ENTIDAD PRINCIPAL:
   ========================================================================== */


/* ----------------------------------------------------------------------------
   PASO 1 (5 min) - Un arreglo simple
   Antes de la tabla, una lista de solo textos. Escribe un arreglo con 3 o 4
   valores que en tu proyecto sean una lista cerrada de opciones.

   Ejemplos según el proyecto:
     Pedidos     -> los estados: "pendiente", "en preparacion", "entregado"
     Inventario  -> las categorías: "Audio", "Cables", "Energía"
     Rutas       -> los puntos de encuentro autorizados
     Veterinaria -> los servicios que presta
     Inmuebles   -> las formas de pago: "hora", "dia", "semana", "mes"

   Después imprime: la lista completa, cuántos elementos tiene, el primero,
   el último (usando .length - 1, no el número a mano) y recórrela con un for.
   ---------------------------------------------------------------------------- */

   //Integrantes: Mateo Carrillo, Leonardo Ruiz.
const tipoInmueble = Object.freeze([ "Casa", "Apartamento", "Local", "Patio", "CasaPatio", "Salón de Eventos" ]);

console.log(tipoInmueble);
console.log(`La lista tiene ${tipoInmueble.length} elementos`);
console.log(`El primero: ${tipoInmueble[0]}`);
console.log(`El último:  ${tipoInmueble[tipoInmueble.length - 1]}`);
 for (let i = 0; i < tipoInmueble.length; i++) {
   console.log(`${i + 1}. ${tipoInmueble[i]}`);
 }


/* ----------------------------------------------------------------------------
   PASO 2 (5 min) - UN objeto de tu entidad
   Toma las variables de tu Taller 1 y júntalas en un solo objeto. Usa los
   MISMOS nombres de campo que ya tenías: no inventes nombres nuevos.

       const registro = {
         campo1: valor,
         campo2: "valor",
         campo3: true
       };

   Después:
     - imprime el objeto completo
     - imprime dos campos sueltos con punto
     - imprime una línea con template literal mezclando varios campos
     - cambia un campo (el que en el Taller 1 era let) y vuelve a imprimirlo
   ---------------------------------------------------------------------------- */
   const inmueble = {
      tipo: "Casa",
      direccion: "Calle 1 # 2-3",
      tipoPago: "mes",
      tamaño: 120.00,
      precio: 150000,
      disponible: true
   };

   console.log(inmueble);
   console.log(inmueble.tipo, inmueble.precio);
   console.log(`El inmueble es un ${inmueble.tipo} ubicado en ${inmueble.direccion}, con un tamaño de ${inmueble.tamaño} m² y un precio de arriendo de $${inmueble.precio}, y esta ${inmueble.disponible ? "disponible" : "no disponible"}.`);
   inmueble.disponible = false;
   console.log(`El inmueble ${inmueble.disponible ? "disponible" : "no esta disponible"}`);

/* ----------------------------------------------------------------------------
   PASO 3 (10 min) - La TABLA: un arreglo de objetos
   Ahora copia ese objeto OCHO veces dentro de un arreglo, cambiándole los
   valores. Los datos los inventas tú, pero tienen que ser verosímiles: el
   dueño de tu negocio debería reconocerlos.

       const registros = [
         { campo1: 1, campo2: "...", campo3: true  },
         { campo1: 2, campo2: "...", campo3: false },
         ... hasta 8
       ];

   Cuida que haya VARIEDAD: que no todos los booleanos sean true, y que los
   números no sean todos iguales. Si todas las filas son iguales, el reporte
   del paso 4 no va a demostrar nada.

   Después imprime cuántas filas tiene, y llega a un dato concreto
   combinando corchete (la fila) y punto (la columna):

       console.log(registros[0].campo2);
       console.log(registros[3].campo1);
   ---------------------------------------------------------------------------- */

   const inmuebles = [
      { tipo: "Casa", direccion: "Calle 1 # 2-3", tipoPago: "mes", tamaño: 120.00, precio: 150000, disponible: false },
      { tipo: "Apartamento", direccion: "Calle 4 # 5-6", tipoPago: "año", tamaño: 80.00, precio: 100000, disponible: false },
      { tipo: "Local", direccion: "Calle 7 # 8-9", tipoPago: "mes", tamaño: 150.00, precio: 200000, disponible: true },
      { tipo: "Patio", direccion: "Calle 10 # 11-12", tipoPago: "dia", tamaño: 200.00, precio: 250000, disponible: false },
      { tipo: "CasaPatio", direccion: "Calle 13 # 14-15", tipoPago: "semana", tamaño: 180.00, precio: 180000, disponible: true },
      { tipo: "Salón de Eventos", direccion: "Calle 16 # 17-18", tipoPago: "dia", tamaño: 300.00, precio: 500000, disponible: false },
      { tipo: "Apartamento", direccion: "Calle 19 # 20-21", tipoPago: "mes", tamaño: 90.00, precio: 120000, disponible: true },
      { tipo: "Casa", direccion: "Calle 22 # 23-24", tipoPago: "año", tamaño: 250.00, precio: 300000, disponible: false }
   ];
   console.log(`La tabla tiene ${inmuebles.length} filas`);
   console.log(inmuebles[2].tamaño);
   console.log(inmuebles[1].direccion);
/* ----------------------------------------------------------------------------
   PASO 4 (10 min) - El reporte, con el bucle de la clase pasada
   Recorre la tabla con un for. En cada vuelta, guarda la fila en una
   variable con nombre propio:

       for (let i = 0; i < registros.length; i++) {
         const r = registros[i];
         ...
       }

   Dentro del bucle:
     a) imprime una línea por fila, con template literal
     b) mete una CONDICIONAL que marque las filas que necesitan atención
        (es la misma regla del Taller 2)
     c) suma a un ACUMULADOR declarado ANTES del bucle
     d) cuenta cuántas quedaron marcadas

   Y DESPUÉS del bucle, fuera de las llaves, imprime el total, el promedio
   (usa Math.round) y cuántas filas quedaron marcadas.

   ⚠️ El acumulador se declara FUERA. Si lo declaras adentro se reinicia en
   cada vuelta y el total te da el valor de la última fila.
   ---------------------------------------------------------------------------- */
   let acumulador = 0;
   let filasat = 0;
   for (let i=0; i < inmuebles.length; i++) {
      const r = inmuebles[i];
      acumulador += r.precio;
      console.log(`El inmueble ${r.tipo} ubicado en ${r.direccion}, con un tamaño de ${r.tamaño} m² y un precio de arriendo de $${r.precio}, y esta ${r.disponible ? "disponible" : "no disponible"}.`);
      if (!r.disponible) {
         console.log(`El inmueble ${r.tipo} ubicado en ${r.direccion} está ocupado.`);
         filasat++;
      }
      console.log(i);
   }
   console.log(`El total es: ${acumulador}`);
   console.log(`El promedio es: ${Math.round(acumulador / inmuebles.length)}`);
   console.log(`Las filas que estan ocupadas son: ${filasat}`);

/* ----------------------------------------------------------------------------
   ANTES DE ENTREGAR - 2 minutos, se marcan de verdad
     [V] Abrí el .html con Live Server y la consola imprimió algo
     [V] El bucle llega hasta  i < registros.length , no  i <=
     [V] No aparece ningún undefined que yo no haya puesto a propósito
     [V] La condicional del paso 4 marcó ALGUNAS filas, no todas ni ninguna
     [V] El total está DESPUÉS del bucle y salió un solo total, no ocho
     [V] Los nombres de todos los integrantes están dentro del archivo
   ---------------------------------------------------------------------------- */


/* ----------------------------------------------------------------------------
   RETO OPCIONAL (+0.3 sobre la nota del taller)
   Agrega una fila más con .push( ) DESPUÉS de haber declarado el arreglo,
   y vuelve a imprimir el total. Explica en un comentario por qué el arreglo
   se declaró con const y aun así lo pudiste modificar.
   ---------------------------------------------------------------------------- */
   const nuevoinmueble = inmuebles.push({ tipo: "Patio", direccion: "Calle 25 # 26-27", tipoPago: "dia", tamaño: 120.00, precio: 300000, disponible: false });
   console.log(`El total con el nuevo inmueble es: ${acumulador + inmuebles[8].precio}`);