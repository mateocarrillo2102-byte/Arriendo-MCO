/* ============================================================================
   TALLER 1 - "LA FICHA DE MI PROYECTO"        Clase 11 · Lunes 21-09-2026
   ----------------------------------------------------------------------------
   OBJETIVO: convertir la entidad principal de TU proyecto integrador en
   variables de JavaScript, y mostrarla en consola como una ficha ordenada.

   ¿Qué es "la entidad principal"? Es la cosa de la que tu proyecto lleva el
   registro. Ejemplos:
       Proyecto de biblioteca      -> entidad: LIBRO
       Proyecto de inventario      -> entidad: PRODUCTO
       Proyecto de citas médicas   -> entidad: CITA
       Proyecto de gimnasio        -> entidad: MIEMBRO
       Proyecto de parqueadero     -> entidad: VEHÍCULO

   CÓMO EJECUTARLO:  node 03-taller1-plantilla.js
   ENTREGA: este mismo archivo, renombrado como  taller1-TUAPELLIDO.js
   ========================================================================== */


/* ----------------------------------------------------------------------------
   PASO 1 (5 min) - Escribe aquí, en texto plano, antes de programar nada:
   ---------------------------------------------------------------------------- */
// Mi proyecto se llama: Plataforma web para la gestion de arrendamientos en Maicao La Guajira
// Mi entidad principal es: inmueble
// Los 6 datos que necesito guardar de ella son:
//   1. Tipo de inmueble: Casa, apartamento, patio,etc   4. Tamaño en metros cuadrados
//   2. Dirección   5. Precio de arriendo
//   3. Tipo de pago: hora, dia, semana, mes, etc   6. disponible: true o false


/* ----------------------------------------------------------------------------
   PASO 2 (10 min) - Declara las 6 variables.
   REGLAS QUE SE CALIFICAN:
     a) Usa const para lo que no cambia y let SOLO para lo que sí cambia.
     R/P: const tipoInmueble, direccion.
     b) Usa al menos 3 tipos distintos (number, string, boolean).
     R/P: const tipoInmueble = "Casa,etc"; // string
     const direccion = "Calle 1 # 2-3"; // string
     let tipoPago = "mes"; // string
     let tamaño = 120.00; // number
     let precioArriendo = 1000000; // number
     let disponible = true; // boolean
     c) Nombres en minúscula inicial y descriptivos: precioUnitario, no p ni x1.
     R/P: 
   ---------------------------------------------------------------------------- */

// EJEMPLO YA RESUELTO (bórralo y pon el tuyo):
const tipoInmueble = Object.freeze(["Casa", "Apartamento", "Patio", "Salon de Eventos"]); // string
const direccion = "Calle 1 # 2-3";    // string
let tipoPago = "mes";                 // string
let tamaño = 120.00;                  // number
let precioArriendo = 1000000;        // number
let disponible = true;                // boolean

// --- TUS 6 VARIABLES ---
// const tipoInmueble;
// const direccion;
// let tipoPago;
// let   tamaño;
// let precioArriendo;
// let disponible;


/* ----------------------------------------------------------------------------
   PASO 3 (5 min) - Comprueba los tipos.
   Imprime el typeof de 3 de tus variables y verifica que sean los que esperabas.
   ---------------------------------------------------------------------------- */

console.log(typeof tipoInmueble);
console.log(typeof direccion);
console.log(typeof tipoPago);
console.log(typeof tamaño);
console.log(typeof precioArriendo);
console.log(typeof disponible);


/* ----------------------------------------------------------------------------
   PASO 4 (10 min) - Arma la ficha con UN SOLO console.log y template literals.
   Debe incluir al menos un dato CALCULADO dentro de ${ }
   (un total, un precio con IVA, un porcentaje, días restantes... lo que aplique).
   ---------------------------------------------------------------------------- */
const casagarcia = {
   nombre   : "Casa Garcia",
  tipoInmueble: "Casa",
   direccion: "Calle 1 # 2-3",
   tipoPago: "mes",
   tamaño: 80.00,
   precioArriendo: 1000000,
   disponible: true
};
IVA = 0.19;
console.log(`FICHA DE ${casagarcia.nombre} de dirección #${casagarcia.direccion}, su precio con IVA es de : $${casagarcia.precioArriendo * IVA}`);


/* ----------------------------------------------------------------------------
   PASO 5 - RETO OPCIONAL (+0.3 en la nota del taller)
   Agrega una variable que llegue como TEXTO (simulando un formulario), por
   ejemplo:  const cantidadDigitada = "4";
   Haz una cuenta con ella SIN convertirla y luego CONVIRTIÉNDOLA con Number().
   Imprime los dos resultados y explica en un comentario por qué son distintos.
   ---------------------------------------------------------------------------- */
const codigoinmueble = "123";
console.log(`Código del inmueble: ${codigoinmueble + 2}`); // concatenacion
console.log(`Código del inmueble: ${Number(codigoinmueble) + 1}`); // suma de numeros